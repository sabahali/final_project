import React from 'react'

const PaymentFail = () => {
  return (
    <div className='d-flex flex-column align-items-center justify-content-center p-4 w-100 ' style={{width :'100vw',minHeight : '80vh'}}>
    <p className='display-1'>Payment Failed </p>
    <p className='display-1'>Try Again </p>

</div>
  )
}

export default PaymentFail